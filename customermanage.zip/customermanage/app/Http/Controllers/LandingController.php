<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\User;
use DB;

class LandingController extends Controller
{
    public function index() {
        
        if(Auth::guest()) {
            return view('welcome');
        }
        else {
            if(Auth::user()->admin == 1) {
                return redirect('/admin-panel');
            }
            else {
                return redirect('/home');
            }
        }
       
    }


    public function userdetails($id)
    {
        if(!empty($id))
        {
        $user = User::findOrFail($id);
        $user_role = DB::table('users')->where('id', '=', $id)->first();
        $userdetails = (array) $user_role;
        echo json_encode($userdetails);
        }
    }

}
